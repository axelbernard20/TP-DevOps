export const environment = {
    production: true,
    base_url: 'http://localhost:3000'
};
