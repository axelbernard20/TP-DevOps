export const environment = {
    production: false,
    base_url: 'http://localhost:3000'
};
